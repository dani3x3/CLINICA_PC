package CLINICA_PC;

import java.util.Scanner;
import java.util.HashMap;
import java.util.Map;

public class Main {
    private static Map<String, Cliente> clientes = new HashMap<>();
    private static Map<String, Computador> computadoresEnReparacion = new HashMap<>();
    private static int clienteIDCounter = 1;
    private static int ordenCounter = 1; // Contador para generar números de orden

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int opcion;
        do {
            System.out.println("¿Qué desea hacer?");
            System.out.println("1. Registrar cliente");
            System.out.println("2. Registrar ingreso de computador");
            System.out.println("3. Buscar cliente");
           // System.out.println("4. Seguir Orden");
            System.out.println("5. Salir");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpia el buffer del scanner

            switch (opcion) {
                case 1:
                    registrarCliente(scanner);
                    break;
                case 2:
                    registrarIngresoComputador(scanner);
                    break;
                case 3:
                    buscarCliente(scanner);
                    break;
                case 4:
                    seguirOrden(scanner);
                    break;
                case 5:
                    System.out.println("¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
                    break;
            }
        } while (opcion != 5);

        scanner.close();
    }

    private static void registrarCliente(Scanner scanner) {
        System.out.println("Ingrese el nombre del cliente:");
        String nombre = scanner.nextLine();
        System.out.println("Ingrese el teléfono del cliente:");
        String telefono = scanner.nextLine();
        Cliente cliente = new Cliente(nombre, telefono);
        clientes.put(cliente.getId(), cliente);
        System.out.println("Cliente registrado con éxito. ID del cliente: " + cliente.getId());
    }

    private static void registrarIngresoComputador(Scanner scanner) {
        System.out.println("Ingrese el ID del cliente:");
        String clienteID = scanner.nextLine();
        Cliente cliente = clientes.get(clienteID);
        if (cliente == null) {
            System.out.println("No se encontró un cliente con ese ID.");
            return;
        }

        System.out.println("Ingrese la marca del computador:");
        String marca = scanner.nextLine();
        System.out.println("Ingrese el modelo del computador:");
        String modelo = scanner.nextLine();
        System.out.println("Ingrese la RAM del computador:");
        String ram = scanner.nextLine();
        System.out.println("Ingrese el procesador del computador:");
        String procesador = scanner.nextLine();
        System.out.println("Ingrese el sistema operativo del computador:");
        String sistemaOperativo = scanner.nextLine();
        System.out.println("Ingrese el costo del computador:");
        double costo = scanner.nextDouble();
        scanner.nextLine(); // Limpia el buffer del scanner

        // Generar un número de orden único
        int numeroOrden = generarNumeroOrden();

        Computador computador = new Computador(marca, modelo, ram, procesador, sistemaOperativo, costo, numeroOrden);
        cliente.agregarComputador(computador);
        computadoresEnReparacion.put(marca + modelo, computador);
        System.out.println("Computador registrado con éxito y asociado al cliente. Número de orden: " + numeroOrden);
    }

    private static int generarNumeroOrden() {
        return ordenCounter++; // Incrementa y devuelve el contador de orden
    }

    private static void buscarCliente(Scanner scanner) {
        System.out.println("Ingrese el ID del cliente:");
        String clienteID = scanner.nextLine();
        Cliente cliente = clientes.get(clienteID);
        if (cliente != null) {
            System.out.println("Nombre del cliente: " + cliente.getNombre());
            System.out.println("Teléfono del cliente: " + cliente.getTelefono());
            System.out.println("Computadores en reparación del cliente:");
            for (Computador computador : cliente.getComputadores()) {
                System.out.println(computador);
            }
        } else {
            System.out.println("No se encontró un cliente con ese ID.");
        }
    }

    private static void seguirOrden(Scanner scanner) {
        // Implementación de esta función según requerimientos adicionales
    }
}

