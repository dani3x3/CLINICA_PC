package CLINICA_PC;

import java.util.ArrayList;
import java.util.List;

public class Cliente {
    private String nombre;
    private String telefono;
    private String id;
    private List<Computador> computadores;

    public Cliente(String nombre, String telefono, String id) {
        this.nombre = nombre;
        this.telefono = telefono;
        this.id = id;
        this.computadores = new ArrayList<>();
    }

    public Cliente(String nombre, String telefono) {
        this.nombre = nombre;
        this.telefono = telefono;
        this.id = generarID();
        this.computadores = new ArrayList<>();
    }

    private String generarID() {
        // Genera un ID único, por ejemplo, usando el nombre y el teléfono del cliente
        return "CLI_" + nombre.substring(0, 3).toUpperCase() + "_" + telefono.substring(0, 3);
    }

    public String getNombre() {
        return nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getId() {
        return id;
    }

    public List<Computador> getComputadores() {
        return computadores;
    }

    public void agregarComputador(Computador computador) {
        computadores.add(computador);
    }
}

