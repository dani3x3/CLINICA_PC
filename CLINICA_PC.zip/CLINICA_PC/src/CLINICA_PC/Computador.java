package CLINICA_PC;

public class Computador {
    private String marca;
    private String modelo;
    private String ram;
    private String procesador;
    private String sistemaOperativo;
    private double costo;
    private int numeroOrden; // Nuevo atributo para el número de orden

    public Computador(String marca, String modelo, String ram, String procesador, String sistemaOperativo, double costo, int numeroOrden) {
        this.marca = marca;
        this.modelo = modelo;
        this.ram = ram;
        this.procesador = procesador;
        this.sistemaOperativo = sistemaOperativo;
        this.costo = costo;
        this.numeroOrden = numeroOrden;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public String getRam() {
        return ram;
    }

    public String getProcesador() {
        return procesador;
    }

    public String getSistemaOperativo() {
        return sistemaOperativo;
    }

    public double getCosto() {
        return costo;
    }

    public int getNumeroOrden() {
        return numeroOrden;
    }

    @Override
    public String toString() {
        return "Marca: " + marca + ", Modelo: " + modelo + ", RAM: " + ram + ", Procesador: " + procesador + ", Sistema Operativo: " + sistemaOperativo + ", Costo: " + costo + ", Número de Orden: " + numeroOrden;
    }
}
